# Quiz-Site

Website built in Django and styled with HTML and CSS that allows user to create their own quizzes or take quizzes created by others.

## Demo

### Taking a Quiz

![take-quiz](https://user-images.githubusercontent.com/24983943/75606171-09dd0100-5a9f-11ea-8ef6-6a908dc65350.gif)

### Creating a Quiz

![create-quiz](https://user-images.githubusercontent.com/24983943/75637200-b3281200-5bd9-11ea-8ed6-35aad893bbe6.gif)
